# Media File Actions

## When To Use
Use when the user asks about images, screenshots, PDFs, audio, video, conversion, resizing, cropping, or aspect ratio changes.

## Steps
1. Inspect the pane context and selected files first.
2. Use Peaker file tools such as `cropImage`, `resizeImage`, `convertImage`, or `convertMedia`.
3. If a visual description is needed, use available image/PDF attachments or selected visible pane content.
4. Report the created output path.

## Constraints
- Prefer Peaker tools over shell scripts for media work.
- Never overwrite the original unless the user explicitly asks.
- Validate all file paths through accessible File panes.
