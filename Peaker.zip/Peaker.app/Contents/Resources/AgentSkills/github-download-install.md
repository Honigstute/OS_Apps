# GitHub Download And Install

## When To Use
Use when the user gives a public project page, repository URL, release page, plugin link, or asks to download or install something.

## Steps
1. Use `webReadURL` before downloading so you know what the page contains.
2. Use `downloadRepositoryArchive` for repository URLs.
3. Use `downloadURL` for direct release assets or files.
4. Use `runTerminalCommand` for non-interactive checks such as listing extracted files.
5. Use `openTerminalCommand` for sudo, package installers, DMGs, PKGs, or commands that may prompt.

## Constraints
- Prefer archives over `git clone` unless the user specifically needs Git history.
- Say where the download landed.
- Do not claim an install is complete when user interaction is still required.
