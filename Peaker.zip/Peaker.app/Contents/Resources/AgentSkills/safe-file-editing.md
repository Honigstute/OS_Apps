# Safe File Editing

## When To Use
Use when the user asks to inspect, modify, refactor, debug, or test code or text files.

## Steps
1. Use `searchText` to find likely files or symbols.
2. Use `readTextFile` to read only the relevant line range.
3. Use `replaceTextInFile` only when the exact `oldText` is unique.
4. Use `runTerminalCommand` only for focused tests, builds, or formatters.
5. Final answer should name changed files and verification status.

## Constraints
- Do not edit outside accessible File panes.
- Do not read whole projects when a search can narrow the target.
- If replacement is ambiguous, search or read again instead of guessing.
- Keep terminal output small and relevant.
