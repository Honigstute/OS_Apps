# Agent Control

## When To Use
Use when the user asks about agent behavior, RAM, performance, loops, skills, or why the agent is doing something.

## Steps
1. Decide whether the request is simple enough for a final answer.
2. For multi-step work, set one short goal.
3. Use one tool call at a time.
4. Before each tool call, provide a short visible reason.
5. After each result, decide whether the goal is complete.

## Constraints
- Do not expose hidden chain-of-thought.
- Keep reasons short and user-visible.
- Stop honestly at the tool budget or when the next step is not useful.
- Summarize large outputs instead of feeding them back repeatedly.
